using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Project.Data;
using Project.Services;
// using Rotativa.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add Entity Framework
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Authentication
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Home/Index";
        options.LogoutPath = "/Home/Logout";
        options.AccessDeniedPath = "/Home/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });

// Add custom services
builder.Services.AddScoped<IPasswordService, PasswordService>();
builder.Services.AddScoped<IAuthService, AuthService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

// Initialize static forms
await CreateStaticForms(app);

app.Run();

static async Task CreateStaticForms(WebApplication app)
{
    using (var scope = app.Services.CreateScope())
    {
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        
        try
        {
            // Check if Modified AIMS form already exists
            var existingForm = await context.Form
                .FirstOrDefaultAsync(f => f.FormName == "Modified AIMS (แบบฟอร์มมาตรฐาน)");

            if (existingForm == null)
            {
                // Create the Modified AIMS form
                var modifiedAimsForm = new Project.Models.Entity.Form
                {
                    FormName = "Modified AIMS (แบบฟอร์มมาตรฐาน)",
                    FormType = 3,
                    Scoring = "sum",
                    Questions = new List<Project.Models.Entity.Question>(),
                    Interpreters = new List<Project.Models.Entity.Interpreter>()
                };

                // Add questions with sections
                var questionsData = new[]
                {
                    // Section I: Face and Mouth
                    new { Section = "I. ใบหน้า และปาก", Text = "กล้ามเนื้อเกี่ยวข้องกับการแสดงความคิดเห็นใบหน้า เช่น การเคลือบใบหน้า หน้าดาง ดื้อ หรือริมฝีปากยิงหรือขวา" },
                    new { Section = "I. ใบหน้า และปาก", Text = "ริมฝีปากและริมรอบปาก เช่น ปากยื่น ปากผุก ปากกิง เซี่ยวง่า" },
                    new { Section = "I. ใบหน้า และปาก", Text = "ขากรรไกร เช่น กัฟฟิล จับกรรไกร เคี้ยวปาก อ้าปาก เคลื่อนไหว ไม่ต้านลิ้น" },
                    new { Section = "I. ใบหน้า และปาก", Text = "ลิ้น ประเมินเพียงการเคลื่อนไหวที่ผิดปกติหรือขัดขวาง ในปาก และไม่สามารถการเคลื่อนไหวอย่างปกติ" },
                    
                    // Section II: Arms and Legs
                    new { Section = "II. แขนและขา", Text = "ส่วนบน (แขน ข้อมือ นิ้ว มือ) มีการเคลื่อนไหวของแขนเคลือบไม่ปกติ มากกว่าเพี่ยงพอ ทั้งข้างซ้ายหรือข้างขวา หรือทั้งการเคลื่อนไหวแบบช้องเพ่ย" },
                    new { Section = "II. แขนและขา", Text = "ล่างส่วน (เท้า เขา ข้อเท้า นิ้วเท้า) โบยเท้าไป-มาข้างลั่ง ดีดเท้าบิน ลื่นทั้งเท้าล่างที่แปงแก้ม กิดเขา" },
                    
                    // Section III: Body
                    new { Section = "III. ลำตัว", Text = "คอ ไหล่ สะเมิน โอน ผิน หมุนเกะดันข้องรวก" },
                    
                    // Section IV: Treatment Monitoring
                    new { Section = "IV. การติดตามการรักษาด้วยยา", Text = "ความรุนแรงของการเคลื่อนไหวผิดปกติทั้งหมด" },
                    new { Section = "IV. การติดตามการรักษาด้วยยา", Text = "การฟื้นฟูความสามารถของการเคลื่อนไหวผิดปกติ" },
                    
                    // Section V: Patient Status  
                    new { Section = "V. สถานะของผู้ป่วย", Text = "การรับรู้ของผู้ป่วยต่อการเคลื่อนไหวผิดปกติ ให้ประเมินความล้มเหลวงันหาย และ/หรือปัญหาปลอดภัยและข้อใด" },
                    new { Section = "V. สถานะของผู้ป่วย", Text = "ปัญหาปีบไฟ้ไป่เหงากลีบ และ/หรือปัญหาปลอดภัยและข้อใด" },
                    new { Section = "V. สถานะของผู้ป่วย", Text = "มีการไส้ภรึ่นปลอดภัยและข้อใด" }
                };

                foreach (var questionData in questionsData)
                {
                    var question = new Project.Models.Entity.Question
                    {
                        QuestionText = questionData.Text,
                        Section = questionData.Section,
                        Options = new List<Project.Models.Entity.Option>()
                    };

                    // Add standard 0-4 options for most questions
                    if (!questionData.Text.Contains("ปัญหาปีบไฟ้") && !questionData.Text.Contains("มีการไส้ภรึ่น"))
                    {
                        for (int i = 0; i <= 4; i++)
                        {
                            var optionText = i switch
                            {
                                0 => "ไม่มีอาการ",
                                1 => "น้อยมาก",
                                2 => "เล็กน้อย", 
                                3 => "ปานกลาง",
                                4 => "รุนแรง",
                                _ => i.ToString()
                            };

                            question.Options.Add(new Project.Models.Entity.Option
                            {
                                OptionText = optionText,
                                Value = i
                            });
                        }
                    }
                    else if (questionData.Text.Contains("ปัญหาปีบไฟ้"))
                    {
                        // Special options for question 11
                        for (int i = 0; i <= 3; i++)
                        {
                            question.Options.Add(new Project.Models.Entity.Option
                            {
                                OptionText = i.ToString(),
                                Value = i
                            });
                        }
                    }
                    else
                    {
                        // Special options for question 12
                        question.Options.Add(new Project.Models.Entity.Option
                        {
                            OptionText = "ไม่ใช่",
                            Value = 0
                        });
                        question.Options.Add(new Project.Models.Entity.Option
                        {
                            OptionText = "ใช่",
                            Value = 1
                        });
                    }

                    modifiedAimsForm.Questions.Add(question);
                }

                // Add custom interpreters for Modified AIMS (not used in custom logic, but for reference)
                var interpreters = new[]
                {
                    new { Min = 0, Max = 0, Name = "ปกติ", Text = "ไม่พบการเคลื่อนไหวผิดปกติที่มีนัยสำคัญ" },
                    new { Min = 1, Max = 100, Name = "ผิดปกติ", Text = "พบการเคลื่อนไหวผิดปกติ - ใช้เกณฑ์พิเศษในการแปลผล" }
                };

                foreach (var interpreter in interpreters)
                {
                    modifiedAimsForm.Interpreters.Add(new Project.Models.Entity.Interpreter
                    {
                        MinScore = interpreter.Min,
                        MaxScore = interpreter.Max,
                        InterName = interpreter.Name,
                        InterText = interpreter.Text
                    });
                }

                context.Form.Add(modifiedAimsForm);
                await context.SaveChangesAsync();
            }
        }
        catch (Exception ex)
        {
            // Log error but don't stop application
            Console.WriteLine($"Error creating static forms: {ex.Message}");
        }
    }
}
